package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.FieldOperation;

@SuppressWarnings("all")
public interface Field_AppendEntryToTableOperation extends lua_exec.revisitor.operations.lua_exec.Field_AppendEntryToTableOperation, FieldOperation, lua_exec.revisitor.operations.lua_exec.FieldOperation {
}
