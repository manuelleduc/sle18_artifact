package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.LastStatementOperation;

@SuppressWarnings("all")
public interface LastStatement_BreakOperation extends lua_exec.revisitor.operations.lua_exec.LastStatement_BreakOperation, LastStatementOperation, lua_exec.revisitor.operations.lua_exec.LastStatementOperation {
}
