/**
 */
package simpleALEnv.impl;

import org.eclipse.emf.ecore.EClass;

import simpleALEnv.ArithPlus;
import simpleALEnv.SimpleALEnvPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arith Plus</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ArithPlusImpl extends ArithOpImpl implements ArithPlus {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArithPlusImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SimpleALEnvPackage.Literals.ARITH_PLUS;
	}

} //ArithPlusImpl
