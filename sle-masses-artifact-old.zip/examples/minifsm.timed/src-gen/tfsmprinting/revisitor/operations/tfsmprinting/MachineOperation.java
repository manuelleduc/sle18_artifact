package tfsmprinting.revisitor.operations.tfsmprinting;

@SuppressWarnings("all")
public interface MachineOperation extends fsmprinting.revisitor.operations.fsmprinting.MachineOperation {
}
