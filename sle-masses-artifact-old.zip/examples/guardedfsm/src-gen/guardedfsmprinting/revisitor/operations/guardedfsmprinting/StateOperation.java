package guardedfsmprinting.revisitor.operations.guardedfsmprinting;

@SuppressWarnings("all")
public interface StateOperation extends fsmprinting.revisitor.operations.fsmprinting.StateOperation {
}
