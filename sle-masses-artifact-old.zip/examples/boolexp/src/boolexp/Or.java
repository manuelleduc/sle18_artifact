/**
 */
package boolexp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Or</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boolexp.BoolexpPackage#getOr()
 * @model
 * @generated
 */
public interface Or extends BinaryExp {
} // Or
