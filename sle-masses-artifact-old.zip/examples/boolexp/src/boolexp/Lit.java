/**
 */
package boolexp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boolexp.BoolexpPackage#getLit()
 * @model abstract="true"
 * @generated
 */
public interface Lit extends Exp {
} // Lit
