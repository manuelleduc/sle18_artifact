package tfsmprinting.revisitor.operations.tfsmprinting;

import fsmprinting.revisitor.operations.fsmprinting.StateOperation;

@SuppressWarnings("all")
public interface FinalStateOperation extends fsmprinting.revisitor.operations.fsmprinting.FinalStateOperation, StateOperation, tfsmprinting.revisitor.operations.tfsmprinting.StateOperation {
}
