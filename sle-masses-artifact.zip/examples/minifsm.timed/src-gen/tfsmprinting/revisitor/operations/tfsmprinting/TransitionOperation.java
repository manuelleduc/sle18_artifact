package tfsmprinting.revisitor.operations.tfsmprinting;

@SuppressWarnings("all")
public interface TransitionOperation extends fsmprinting.revisitor.operations.fsmprinting.TransitionOperation {
}
