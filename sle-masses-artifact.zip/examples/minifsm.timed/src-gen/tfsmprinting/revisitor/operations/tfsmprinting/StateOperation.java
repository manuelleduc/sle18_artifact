package tfsmprinting.revisitor.operations.tfsmprinting;

@SuppressWarnings("all")
public interface StateOperation extends fsmprinting.revisitor.operations.fsmprinting.StateOperation {
}
