package guardedfsmprinting.revisitor.operations.guardedfsmprinting;

import printexp.revisitor.operations.printexp.ExpOperation;

@SuppressWarnings("all")
public interface LitOperation extends printexp.revisitor.operations.printexp.LitOperation, ExpOperation, guardedfsmprinting.revisitor.operations.guardedfsmprinting.ExpOperation {
}
