package guardedfsmprinting.revisitor.operations.guardedfsmprinting;

import fsmprinting.revisitor.operations.fsmprinting.StateOperation;

@SuppressWarnings("all")
public interface FinalStateOperation extends fsmprinting.revisitor.operations.fsmprinting.FinalStateOperation, StateOperation, guardedfsmprinting.revisitor.operations.guardedfsmprinting.StateOperation {
}
