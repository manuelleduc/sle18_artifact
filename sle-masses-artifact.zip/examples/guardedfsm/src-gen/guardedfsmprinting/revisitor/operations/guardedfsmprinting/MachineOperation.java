package guardedfsmprinting.revisitor.operations.guardedfsmprinting;

@SuppressWarnings("all")
public interface MachineOperation extends fsmprinting.revisitor.operations.fsmprinting.MachineOperation {
}
