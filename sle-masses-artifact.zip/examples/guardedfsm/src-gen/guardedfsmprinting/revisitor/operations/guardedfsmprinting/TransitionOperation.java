package guardedfsmprinting.revisitor.operations.guardedfsmprinting;

@SuppressWarnings("all")
public interface TransitionOperation extends fsmprinting.revisitor.operations.fsmprinting.TransitionOperation {
}
