package guardedfsmprinting.revisitor.operations.guardedfsmprinting;

import printexp.revisitor.operations.printexp.ExpOperation;

@SuppressWarnings("all")
public interface BinaryExpOperation extends printexp.revisitor.operations.printexp.BinaryExpOperation, ExpOperation, guardedfsmprinting.revisitor.operations.guardedfsmprinting.ExpOperation {
}
