package guardedfsmprinting.revisitor.operations.guardedfsmprinting;

import printexp.revisitor.operations.printexp.ExpOperation;
import printexp.revisitor.operations.printexp.LitOperation;

@SuppressWarnings("all")
public interface FalsOperation extends printexp.revisitor.operations.printexp.FalsOperation, LitOperation, guardedfsmprinting.revisitor.operations.guardedfsmprinting.LitOperation, ExpOperation, guardedfsmprinting.revisitor.operations.guardedfsmprinting.ExpOperation {
}
