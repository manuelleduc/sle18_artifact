package guardedfsmprinting.revisitor.operations.guardedfsmprinting;

import printexp.revisitor.operations.printexp.BinaryExpOperation;
import printexp.revisitor.operations.printexp.ExpOperation;

@SuppressWarnings("all")
public interface AndOperation extends printexp.revisitor.operations.printexp.AndOperation, BinaryExpOperation, guardedfsmprinting.revisitor.operations.guardedfsmprinting.BinaryExpOperation, ExpOperation, guardedfsmprinting.revisitor.operations.guardedfsmprinting.ExpOperation {
}
