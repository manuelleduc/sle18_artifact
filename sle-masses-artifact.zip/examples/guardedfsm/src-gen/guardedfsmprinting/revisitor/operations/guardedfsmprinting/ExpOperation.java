package guardedfsmprinting.revisitor.operations.guardedfsmprinting;

@SuppressWarnings("all")
public interface ExpOperation extends printexp.revisitor.operations.printexp.ExpOperation {
}
