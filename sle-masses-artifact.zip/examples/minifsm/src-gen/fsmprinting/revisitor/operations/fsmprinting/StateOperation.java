package fsmprinting.revisitor.operations.fsmprinting;

@SuppressWarnings("all")
public interface StateOperation {
  public abstract String print();
}
