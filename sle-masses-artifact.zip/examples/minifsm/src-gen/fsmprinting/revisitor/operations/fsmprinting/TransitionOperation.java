package fsmprinting.revisitor.operations.fsmprinting;

@SuppressWarnings("all")
public interface TransitionOperation {
  public abstract String print();
}
