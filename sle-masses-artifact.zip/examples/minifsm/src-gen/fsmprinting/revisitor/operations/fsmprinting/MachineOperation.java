package fsmprinting.revisitor.operations.fsmprinting;

@SuppressWarnings("all")
public interface MachineOperation {
  public abstract String print();
}
