package printexp.revisitor.operations.printexp;

@SuppressWarnings("all")
public interface ExpOperation {
  public abstract String print();
}
