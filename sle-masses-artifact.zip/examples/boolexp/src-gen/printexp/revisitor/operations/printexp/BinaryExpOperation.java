package printexp.revisitor.operations.printexp;

import printexp.revisitor.operations.printexp.ExpOperation;

@SuppressWarnings("all")
public interface BinaryExpOperation extends ExpOperation {
}
