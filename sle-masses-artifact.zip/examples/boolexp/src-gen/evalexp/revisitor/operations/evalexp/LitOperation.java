package evalexp.revisitor.operations.evalexp;

import evalexp.revisitor.operations.evalexp.ExpOperation;

@SuppressWarnings("all")
public interface LitOperation extends ExpOperation {
}
