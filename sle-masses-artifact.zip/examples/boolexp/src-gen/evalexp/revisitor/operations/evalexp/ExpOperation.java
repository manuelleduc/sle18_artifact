package evalexp.revisitor.operations.evalexp;

@SuppressWarnings("all")
public interface ExpOperation {
  public abstract boolean eval();
}
