/**
 */
package boolexp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fals</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boolexp.BoolexpPackage#getFals()
 * @model
 * @generated
 */
public interface Fals extends Lit {
} // Fals
