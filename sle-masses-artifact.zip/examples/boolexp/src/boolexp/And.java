/**
 */
package boolexp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>And</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boolexp.BoolexpPackage#getAnd()
 * @model
 * @generated
 */
public interface And extends BinaryExp {
} // And
