/**
 */
package boolexp.impl;

import boolexp.BoolexpPackage;
import boolexp.Tru;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tru</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TruImpl extends LitImpl implements Tru {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TruImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BoolexpPackage.Literals.TRU;
	}

} //TruImpl
