/**
 */
package boolexp.impl;

import boolexp.BoolexpPackage;
import boolexp.Fals;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fals</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FalsImpl extends LitImpl implements Fals {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FalsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BoolexpPackage.Literals.FALS;
	}

} //FalsImpl
