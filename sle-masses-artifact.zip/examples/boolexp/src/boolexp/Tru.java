/**
 */
package boolexp;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tru</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boolexp.BoolexpPackage#getTru()
 * @model
 * @generated
 */
public interface Tru extends Lit {
} // Tru
