/**
 */
package simpleALEnv.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import simpleALEnv.Arith;
import simpleALEnv.SimpleALEnvPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Arith</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ArithImpl extends MinimalEObjectImpl.Container implements Arith {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ArithImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SimpleALEnvPackage.Literals.ARITH;
	}

} //ArithImpl
