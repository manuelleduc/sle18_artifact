/**
 */
package simpleALEnv;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arith Minus</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see simpleALEnv.SimpleALEnvPackage#getArithMinus()
 * @model
 * @generated
 */
public interface ArithMinus extends ArithOp {
} // ArithMinus
