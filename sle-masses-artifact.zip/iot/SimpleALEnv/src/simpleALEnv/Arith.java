/**
 */
package simpleALEnv;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arith</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see simpleALEnv.SimpleALEnvPackage#getArith()
 * @model abstract="true"
 * @generated
 */
public interface Arith extends EObject {
} // Arith
