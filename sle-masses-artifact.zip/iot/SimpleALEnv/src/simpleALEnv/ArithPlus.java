/**
 */
package simpleALEnv;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Arith Plus</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see simpleALEnv.SimpleALEnvPackage#getArithPlus()
 * @model
 * @generated
 */
public interface ArithPlus extends ArithOp {
} // ArithPlus
