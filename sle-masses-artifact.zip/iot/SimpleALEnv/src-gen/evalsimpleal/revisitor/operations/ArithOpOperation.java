package evalsimpleal.revisitor.operations;

import evalsimpleal.revisitor.operations.ArithOperation;

@SuppressWarnings("all")
public interface ArithOpOperation extends ArithOperation {
}
