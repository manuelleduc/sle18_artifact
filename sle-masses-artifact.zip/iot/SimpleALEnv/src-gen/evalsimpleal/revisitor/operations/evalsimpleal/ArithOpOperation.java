package evalsimpleal.revisitor.operations.evalsimpleal;

import evalsimpleal.revisitor.operations.evalsimpleal.ArithOperation;

@SuppressWarnings("all")
public interface ArithOpOperation extends ArithOperation {
}
