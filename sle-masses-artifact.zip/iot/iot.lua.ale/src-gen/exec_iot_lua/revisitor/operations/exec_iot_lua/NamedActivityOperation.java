package exec_iot_lua.revisitor.operations.exec_iot_lua;

@SuppressWarnings("all")
public interface NamedActivityOperation extends activitydiagram_exec.revisitor.operations.activitydiagram_exec.NamedActivityOperation {
}
