package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.ValueOperation;

@SuppressWarnings("all")
public interface IntegerValueOperation extends activitydiagram_exec.revisitor.operations.activitydiagram_exec.IntegerValueOperation, ValueOperation, activitydiagram_exec.revisitor.operations.activitydiagram_exec.ValueOperation {
}
