package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.IotActivityOperation;

@SuppressWarnings("all")
public interface IotActivityBindActivityOperation extends IotActivityOperation {
  public abstract long main();
}
