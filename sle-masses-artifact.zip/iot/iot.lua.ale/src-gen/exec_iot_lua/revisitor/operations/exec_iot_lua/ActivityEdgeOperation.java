package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.NamedActivityOperation;

@SuppressWarnings("all")
public interface ActivityEdgeOperation extends activitydiagram_exec.revisitor.operations.activitydiagram_exec.ActivityEdgeOperation, NamedActivityOperation, activitydiagram_exec.revisitor.operations.activitydiagram_exec.NamedActivityOperation {
}
