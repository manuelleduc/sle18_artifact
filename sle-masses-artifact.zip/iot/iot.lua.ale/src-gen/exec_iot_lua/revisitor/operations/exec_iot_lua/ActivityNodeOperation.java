package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.NamedActivityOperation;

@SuppressWarnings("all")
public interface ActivityNodeOperation extends activitydiagram_exec.revisitor.operations.activitydiagram_exec.ActivityNodeOperation, NamedActivityOperation, activitydiagram_exec.revisitor.operations.activitydiagram_exec.NamedActivityOperation {
}
