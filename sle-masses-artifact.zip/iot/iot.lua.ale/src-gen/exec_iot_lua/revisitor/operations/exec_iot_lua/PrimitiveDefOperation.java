package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.IDLTypeOperation;

@SuppressWarnings("all")
public interface PrimitiveDefOperation extends IDLTypeOperation {
}
