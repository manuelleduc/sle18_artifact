package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.TokenOperation;

@SuppressWarnings("all")
public interface ControlTokenOperation extends activitydiagram_exec.revisitor.operations.activitydiagram_exec.ControlTokenOperation, TokenOperation, activitydiagram_exec.revisitor.operations.activitydiagram_exec.TokenOperation {
}
