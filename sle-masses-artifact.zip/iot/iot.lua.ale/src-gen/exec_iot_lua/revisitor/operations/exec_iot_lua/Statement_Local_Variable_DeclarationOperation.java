package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.StatementOperation;

@SuppressWarnings("all")
public interface Statement_Local_Variable_DeclarationOperation extends lua_exec.revisitor.operations.lua_exec.Statement_Local_Variable_DeclarationOperation, StatementOperation, lua_exec.revisitor.operations.lua_exec.StatementOperation {
}
