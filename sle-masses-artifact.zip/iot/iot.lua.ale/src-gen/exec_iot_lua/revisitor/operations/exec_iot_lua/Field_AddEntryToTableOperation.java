package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.FieldOperation;

@SuppressWarnings("all")
public interface Field_AddEntryToTableOperation extends lua_exec.revisitor.operations.lua_exec.Field_AddEntryToTableOperation, FieldOperation, lua_exec.revisitor.operations.lua_exec.FieldOperation {
}
