package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.HWCompOperation;

@SuppressWarnings("all")
public interface ActuatorOperation extends HWCompOperation {
}
