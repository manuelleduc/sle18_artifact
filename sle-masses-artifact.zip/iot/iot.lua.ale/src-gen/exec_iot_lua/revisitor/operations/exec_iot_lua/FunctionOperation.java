package exec_iot_lua.revisitor.operations.exec_iot_lua;

@SuppressWarnings("all")
public interface FunctionOperation extends lua_exec.revisitor.operations.lua_exec.FunctionOperation {
}
