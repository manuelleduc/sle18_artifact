package exec_iot_lua.revisitor.operations.exec_iot_lua;

@SuppressWarnings("all")
public interface Statement_If_Then_Else_ElseIfPartOperation extends lua_exec.revisitor.operations.lua_exec.Statement_If_Then_Else_ElseIfPartOperation {
}
