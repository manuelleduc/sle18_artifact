package exec_iot_lua.revisitor.operations.exec_iot_lua;

@SuppressWarnings("all")
public interface ValueOperation extends activitydiagram_exec.revisitor.operations.activitydiagram_exec.ValueOperation {
}
