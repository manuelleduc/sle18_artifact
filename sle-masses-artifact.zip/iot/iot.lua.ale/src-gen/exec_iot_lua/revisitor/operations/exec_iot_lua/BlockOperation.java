package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.ChunkOperation;

@SuppressWarnings("all")
public interface BlockOperation extends lua_exec.revisitor.operations.lua_exec.BlockOperation, ChunkOperation, lua_exec.revisitor.operations.lua_exec.ChunkOperation {
}
