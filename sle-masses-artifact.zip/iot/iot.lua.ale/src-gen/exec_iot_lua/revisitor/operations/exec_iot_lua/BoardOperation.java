package exec_iot_lua.revisitor.operations.exec_iot_lua;

@SuppressWarnings("all")
public interface BoardOperation {
}
