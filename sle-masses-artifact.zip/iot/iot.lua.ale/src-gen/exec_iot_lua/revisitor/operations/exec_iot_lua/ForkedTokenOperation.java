package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.TokenOperation;

@SuppressWarnings("all")
public interface ForkedTokenOperation extends activitydiagram_exec.revisitor.operations.activitydiagram_exec.ForkedTokenOperation, TokenOperation, activitydiagram_exec.revisitor.operations.activitydiagram_exec.TokenOperation {
}
