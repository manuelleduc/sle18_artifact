package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.LastStatementOperation;

@SuppressWarnings("all")
public interface LastStatement_ReturnOperation extends lua_exec.revisitor.operations.lua_exec.LastStatement_ReturnOperation, LastStatementOperation, lua_exec.revisitor.operations.lua_exec.LastStatementOperation {
}
