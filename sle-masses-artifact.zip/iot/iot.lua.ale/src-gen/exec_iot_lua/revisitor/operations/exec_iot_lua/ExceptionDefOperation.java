package exec_iot_lua.revisitor.operations.exec_iot_lua;

import exec_iot_lua.revisitor.operations.exec_iot_lua.ContainedOperation;
import exec_iot_lua.revisitor.operations.exec_iot_lua.NamedElementOperation;

@SuppressWarnings("all")
public interface ExceptionDefOperation extends ContainedOperation, NamedElementOperation {
}
